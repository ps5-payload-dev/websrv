const SCRIPTPATH = window.location.pathname.substring(3)
const SCRIPTDIR = SCRIPTPATH.substring(0, SCRIPTPATH.lastIndexOf('/'));

async function launchRom(filename) {
    const path = SCRIPTDIR + '/eboot.elf';
    const args = SCRIPTDIR + '/roms/' + filename;
    await fetch('/hbldr?path=' + path + '&args=' + args);
}

async function getRomsList() {
    let response = await fetch('roms/?fmt=json');
    let data = await response.json();
    return data;
}

async function renderSnesList() {
    const list = await getRomsList();
    
    list.forEach(entry => {
	if(!entry.name.endsWith(".smc") && !entry.name.endsWith(".sfc")) {
	    return;
	}

	const title = entry.name.slice(0, -4); 
	const icon = document.createElement('img');
	icon.src = 'roms/' + title + '.jpg';
	icon.alt = title;
	
	const link = document.createElement('a');
	link.href = '#';
	link.onclick = async function() {
	    launchRom(entry.name);
	}
	
	link.appendChild(icon);
	document.body.appendChild(link);
    });
}
